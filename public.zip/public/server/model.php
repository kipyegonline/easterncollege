<?php

class Model {
    public function __construct(){
        try{
 $this->connection=new PDO("mysql:host=localhost;dbname=easternCollege","vince","//matata11");
 
        }
        catch(PDOException $e){
echo "error connection to DB ". $e->getMessage();
        }
        //return $this->connection;
       
    }
 protected function fetch($query){
        $stmt=$this->connection->query($query);
        if($stmt){
            $data=$stmt->fetchAll(PDO::FETCH_ASSOC);
            return json_encode($data);
        }
    }
    protected function insertDB($sql,$array){
       $stmt= $this->connection->prepare($sql);
       if($stmt){
            
        $stmt->execute($array);
       return  $this->connection->lastInsertId();
       }       

    }
    protected function executeDB($query){
        $res=$this->connection->exec($query);
        return $res;
    }
}