<?php
require("./model.php");
class ServiceWorker extends Model{
    public function __construct($name){
        $this->model=new Model();
        $this->name=$name;
        $this->connection=$this->model->connection;
       
    }
// insert schools
    public function insertSchools($school){
        $query="INSERT INTO eastern_college_schools (school) values('$school')";
        $stmt=$this->model->connection->query($query);
        if($stmt){
            echo $this->connection->lastInsertId();

        }

    }
    // fetch schools
    public function fetchSchools(){
$query="SELECT * from eastern_college_schools order by id";
$data=$this->model->fetch($query);
echo $data;
    }
    //insert courses
    public function insertCOurses($data){
        $sql="INSERT INTO eastern_college_courses (school_id,coursename,coursecode,level,period,intakes,des,addedBy,addedon)
        VALUES(:school_id,:coursename,:coursecode,:level,:period,:intakes,:des,:addedBy,NOW())";
        $arr=[":school_id"=>$data->school,":coursename"=>$data->courseName,":coursecode"=>$data->courseCode,":level"=>$data->level,":period"=>$data->period,":intakes"=>$data->intakes,":des"=>$data->des,":addedBy"=>$data->addedBy];
        $id=$this->model->insertDB($sql,$arr);       
       return $id;
    }
    //fetch courses
    public function fetchCourses($id){
        if($id){
        $query="SELECT * from eastern_college_courses where school_id='$id' ORDER BY id ";
        $data=$this->model->fetch($query);
        echo $data; 
                }else{
        $query="SELECT * from eastern_college_courses ORDER BY id ";
        $data=$this->model->fetch($query);
        echo $data; 
        }
    }
    // delete course
    public function deleteCourse($id){
        $sql="DELETE FROM eastern_college_courses where id=$id LIMIT 1";
        $res=$this->model->executeDB($sql);
        echo $res;
    }
    //record metrics
    public function recordMetrics($uuid,$ip,$visitor){
       
        if($visitor){
            $sql="INSERT INTO eastern_college_sitehits (altId,ipAddress,addedon) VALUES(:altId,:ipaddress,NOW()) ";
            $arr=["altId"=>$uuid,":ipaddress"=>$ip];
             $id=$this->model->insertDB($sql,$arr);           


        }else{
            // verify user
            $sq1="SELECT * from eastern_college_sitehits  where altId='$uuid' LIMIT 1 ";
            $stmt=$this->connection->query($sq1);
            $data=$stmt->fetch(PDO::FETCH_ASSOC);          
            //get count
            $counter=$data['usercounter'] + 1;            
            //update count
         $sq2="UPDATE eastern_college_sitehits set usercounter=$counter   where altId='$uuid' LIMIT 1  ";
        $res=$this->model->executeDB($sq2);
        
    }

    }
    // add news
    public function addNews($data){
        $sql="INSERT INTO eastern_college_news (title,body,date,addedBy,addedon) VALUES(:title,:body,:date,:addedBy,NOW())";
        $arr=[":title"=>$data->title,":body"=>$data->body,":date"=>$data->date,":addedBy"=>$data->addedBy];
        $id=$id=$this->model->insertDB($sql,$arr);    
       return  $id;
    }
    // add notice
      public function addNotice($data){
        $sql="INSERT INTO eastern_college_notices (title,body,date,addedBy,addedon) VALUES(:title,:body,:date,:addedBy,NOW())";
        $arr=[":title"=>$data->title,":body"=>$data->body,":date"=>$data->date,":addedBy"=>$data->addedBy];
        $id=$id=$this->model->insertDB($sql,$arr);    
       return  $id;
    }
    // website form
    public function addWebsiteForm($data){
         $sql="INSERT INTO eastern_college_website_form (phone, email,subject,message,addedon)
          VALUES(:phone, :email,:subject,:message,NOW())";
        $arr=[":phone"=>$data->phone,":email"=>$data->email,":subject"=>$data->subject,":message"=>$data->message];
        $id=$this->model->insertDB($sql,$arr);    
       return  $id;

    }
    // fetch
    public function fetchItems($query){
        $data=$this->model->fetch($query);
        echo $data;
    }
    private function checkDuplicates($query){
         $stmt=$this->connection->query($query);
        if($stmt){
            $data=$stmt->fetch(PDO::FETCH_ASSOC);
            return $data["count"];
        }
        
       

    }
    // login
    public function loginUser($data){
        
       $checker="SELECT COUNT(*) count from eastern_college_useradmins where useremail='{$data->email}'";
  
    if(!$this->checkDuplicates($checker)){
        echo json_encode(["status"=>201,"msg"=>"The email address {$data->email} doesn't exist here."]);
    }else{
       $info="SELECT * from eastern_college_useradmins where useremail='{$data->email}'"; 
      $stmt=$this->connection->query($info);
      $user=$stmt->fetch(PDO::FETCH_ASSOC);
      
      if(password_verify($data->password,$user["userpassword"])){
          
          echo json_encode(["status"=>200,"username"=>$user["username"], 
          "email"=>$user["useremail"],"altId"=>$user["altId"]]);

      }else{
         echo json_encode(["status"=>201,"msg"=>"Incorrect email/password combination. Try again"]);  
      }
      
    }
    }
    // sign up user
    public function signUpUser($data){
 //check if email exists
   
   
    $checker="SELECT count(*) count from eastern_college_useradmins where useremail='{$data->useremail}'";
    if($this->checkDuplicates($checker)){
        echo json_encode(["status"=>201,"msg"=>"This email address already exists on the system."]);
    }else{
  
$pword=password_hash($data->userpassword,PASSWORD_DEFAULT,["cost"=>10]);

    $sql="INSERT INTO eastern_college_useradmins (username,useremail,userpassword,altId,active,addedon) VALUES(:username, :useremail,:userpassword,:altId,0,NOW())";
   $bind=[":username"=>$data->username,":useremail"=>$data->useremail,":userpassword"=>$pword,":altId"=>$data->altId];
   
      $id=$this->model->insertDB($sql,$bind); 
     $id>0 ? $res= ["status"=>200,"msg"=>"Account created. Kindly await activation"] : $res= ["status"=>201,"msg"=>"Error signing up..Try again later."];
  echo json_encode($res);
    }
    
    }
public function addEvent($data){
  
$sql="INSERT INTO eastern_college_events (title,altId,details,startdate,enddate,venue,addedon)
 VALUES(:eventname,:altId, :details,:startdate,:enddate,:venue, NOW())";
 $bind=[
     ":eventname"=> $data->eventname,
     ":altId"=>"eastern",
 ":details"=>  $data->details,
 ":startdate"=> $data->startdate,
 ":enddate"=> $data->enddate,
 ":venue"=> $data->venue];
 $id=$this->model->insertDB($sql,$bind);   

 return $id;
    }
    public function deleteEvent($query){
         $res=$this->model->executeDB($query);
         return $res;
    }
}

