<?php
require("./workerclass.php");
$worker=new ServiceWorker("Users");
if(isset($_GET["fetchschools"]) ){
    $worker->fetchSchools();

}
if(isset($_GET["addcourses"]) && $_GET["addcourses"] ){
 $data=json_decode(file_get_contents("php://input")); 
$id=$worker->insertCourses($data);
echo $id > 0 ? json_encode(["status"=>200,"msg"=>"Course added successfully"]) :  json_encode(["status"=>201,"msg"=>"Error adding course"]) ;

}
if(isset($_GET["fetchcourses"]) ){
     
    $courseId=$_GET["courseId"];
$worker->fetchCourses($courseId);
}
if(isset($_GET["deletecourse"]) AND $_GET["deletecourse"]=="true" ){
    $courseId=$_GET["courseId"];
$worker->deleteCourse($courseId);
}
if(isset($_GET["addnews"]) AND $_GET["addnews"]=="true" ){
     $data=json_decode(file_get_contents("php://input"));     
      $id=$worker->addNews($data);
      echo $id > 0 ? json_encode(["status"=>200,"msg"=>"News added successfully"]) :  json_encode(["status"=>201,"msg"=>"Error adding news"]) ;
}
if(isset($_GET["addnotice"]) AND $_GET["addnotice"]=="true" ){
     $data=json_decode(file_get_contents("php://input"));     
      $id=$worker->addNotice($data);
      echo $id > 0 ? json_encode(["status"=>200,"msg"=>"Notice added successfully"]) :  json_encode(["status"=>201,"msg"=>"Error adding notice"]) ;
}
if(isset($_GET["fetchnews"]) AND $_GET["fetchnews"]=="true" ){
    $worker->fetchItems("SELECT * from eastern_college_news order by id desc");
}
if(isset($_GET["fetchforms"]) AND $_GET["fetchforms"]=="true" ){
    $worker->fetchItems("SELECT * from eastern_college_website_form order by id desc");
}
if(isset($_GET["fetchnotices"]) AND $_GET["fetchnotices"]=="true" ){
      $worker->fetchItems("SELECT * from eastern_college_notices order by id desc");
}
if(isset($_GET["loginuser"]) AND $_GET["loginuser"]=="true" ){
    $data=json_decode(file_get_contents("php://input"));
   
    if(strlen($data->email) >6 && strlen($data->password)>5){
    $worker->loginUser($data);
    }
      
}
if(isset($_GET["signupuser"]) AND $_GET["signupuser"]=="true" ){
     $data=json_decode(file_get_contents("php://input"));
    
     if(strlen($data->useremail) >6 && strlen($data->userpassword)>5){
 $worker->signUpUser($data);
     }
     
}
if(isset($_GET["fetchevents"]) AND $_GET["fetchevents"]=="true" ){
 $worker->fetchItems("SELECT * from eastern_college_events order by id desc");
}
if(isset($_GET["setticks"]) AND $_GET["setticks"]=="true" ){
$id=$_GET["uuid"];

  $worker->fetchItems("UPDATE  eastern_college_website_form set seen=1  where id=$id LIMIT 1");
}
if(isset($_GET["addevent"]) AND $_GET["addevent"]=="true" ){
 $data=json_decode(file_get_contents("php://input"));
 
 $id=$worker->addEvent($data);
 echo $id > 0 ? json_encode(["status"=>200,"msg"=>"Event added successfully"]) :  json_encode(["status"=>201,"msg"=>"Error adding event"]) ;
}
if(isset($_GET["deleteevent"]) AND $_GET["deleteevent"]=="true" ){
    $eventId=$_GET["eventId"];
    if($eventId){
       
 $sql="DELETE FROM eastern_college_events where id=$eventId LIMIT 1";
     $id=$worker->deleteEvent($sql);
    }
   
    
}
if(isset($_GET["recordmetrics"]) AND $_GET["recordmetrics"]=="true" ){
    $uuid=$_GET["uuid"];
    $visitor=$_GET['lastvisit'];
    $ip=$_SERVER["REMOTE_ADDR"];
 

$worker->recordMetrics($uuid,$ip,$visitor);
}
if(isset($_GET["websiteform"]) AND $_GET["websiteform"]=="true" ){
     $data=json_decode(file_get_contents("php://input"));
     $id=$worker->addWebsiteForm($data);
      echo $id > 0 ? json_encode(["status"=>200,"msg"=>"Message submitted successfully. We will get back you shortly"]) : 
       json_encode(["status"=>201,"msg"=>"Error submitting message. Try again later or send email to info@eastercollege.so"]) ;

}
 //$worker->fetchSchools();

 //function __autoload($classname){
   